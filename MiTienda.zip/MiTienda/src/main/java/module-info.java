module com.clinica.mitienda {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.clinica.mitienda to javafx.fxml;
    exports com.clinica.mitienda;
}