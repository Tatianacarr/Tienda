package com.clinica.mitienda;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {
    @FXML
    private TextField txtUsuario;
    

    @FXML
    private PasswordField txtPassword;

    @FXML
    private ComboBox<String> cbRol;

    @FXML
    private Button btnIngresar;

    @FXML
    public void initialize() {

        cbRol.getItems().addAll(
                "Administrador",
                "Vendedor",
                "Cajero"
        );

        cbRol.setValue("Administrador");
    }
    

    @FXML
    private void ingresar() {

        String correo = txtUsuario.getText();
        String password = txtPassword.getText();
        String rol = cbRol.getValue();

        if (correo.isEmpty() ||
                password.isEmpty() ||
                rol == null) {

            Alert alerta = new Alert(Alert.AlertType.WARNING);
            alerta.setTitle("Campos Vacíos");
            alerta.setHeaderText(null);
            alerta.setContentText(
                    "Complete todos los campos.");
            alerta.showAndWait();

            return;
        }

        if (correo.equals("admin@gmail.com")
                && password.equals("1234")
                && rol.equals("Administrador")) {

            try {

                Alert alerta = new Alert(Alert.AlertType.INFORMATION);
                alerta.setTitle("Correcto");
                alerta.setHeaderText(null);
                alerta.setContentText(
                        "Inicio de sesión exitoso");
                alerta.showAndWait();

                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource(
                                "/com/clinica/mitienda/dashboard-view.fxml"));

                Parent root = loader.load();

                Stage dashboard = new Stage();

                dashboard.setTitle("MiTienda");
                dashboard.setScene(new Scene(root));
                dashboard.setMaximized(true);
                dashboard.show();

                Stage login =
                        (Stage) btnIngresar.getScene().getWindow();

                login.close();

            } catch (Exception e) {

                e.printStackTrace();

                Alert alerta = new Alert(Alert.AlertType.ERROR);
                alerta.setTitle("Error");
                alerta.setHeaderText(null);
                alerta.setContentText(
                        "No se pudo abrir el Dashboard");
                alerta.showAndWait();
            }

        } else {

            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("Error");
            alerta.setHeaderText(null);
            alerta.setContentText(
                    "Correo, contraseña o rol incorrectos");
            alerta.showAndWait();
        }
    }
}