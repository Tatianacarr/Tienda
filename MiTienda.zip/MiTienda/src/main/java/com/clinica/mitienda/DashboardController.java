package com.clinica.mitienda;

import javafx.fxml.FXML;

public class DashboardController {

    @FXML
    public void initialize() {

    }

    @FXML
    private void nuevoProducto() {

    }

    @FXML
    private void guardarProducto() {

    }

    @FXML
    private void actualizarProducto() {

    }

    @FXML
    private void eliminarProducto() {

    }

    @FXML
    private void limpiarCampos() {

    }
}